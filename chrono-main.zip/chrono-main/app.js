var _0x3dcd55 = _0x3795;
(function (_0xaae0df, _0xa74249) {
    var _0x4191c7 = _0x3795, _0x5df8a4 = _0xaae0df();
    while (!![]) {
        try {
            var _0x548b97 = -parseInt(_0x4191c7(0x110)) / 0x1 * (-parseInt(_0x4191c7(0xfd)) / 0x2) + parseInt(_0x4191c7(0x111)) / 0x3 + parseInt(_0x4191c7(0x11e)) / 0x4 * (parseInt(_0x4191c7(0xff)) / 0x5) + -parseInt(_0x4191c7(0xfc)) / 0x6 * (-parseInt(_0x4191c7(0x11b)) / 0x7) + parseInt(_0x4191c7(0x120)) / 0x8 * (-parseInt(_0x4191c7(0x122)) / 0x9) + -parseInt(_0x4191c7(0x10a)) / 0xa + parseInt(_0x4191c7(0x10d)) / 0xb;
            if (_0x548b97 === _0xa74249) break; else _0x5df8a4['push'](_0x5df8a4['shift']());
        } catch (_0x22fe22) {
            _0x5df8a4['push'](_0x5df8a4['shift']());
        }
    }
}(_0x2c2f, 0xb24f0));
var express = require(_0x3dcd55(0x107)),
    app = module[_0x3dcd55(0x102)] = express['createServer'](express[_0x3dcd55(0xf6)]()),
    io = require(_0x3dcd55(0xfe))[_0x3dcd55(0x118)](app);

function _0x3795(_0x5b7eca, _0x484005) {
    var _0x2c2fb8 = _0x2c2f();
    return _0x3795 = function (_0x37951a, _0x5cb47b) {
        _0x37951a = _0x37951a - 0xf6;
        var _0xe0fe20 = _0x2c2fb8[_0x37951a];
        return _0xe0fe20;
    }, _0x3795(_0x5b7eca, _0x484005);
}

Stopwatch = require(_0x3dcd55(0x10b)), routes = require(_0x3dcd55(0x11a)), app[_0x3dcd55(0x105)](function () {
    var _0x5a5291 = _0x3dcd55;
    app['set']('views', __dirname + '/views'), app['set'](_0x5a5291(0x10f), _0x5a5291(0x117)), app[_0x5a5291(0x108)](express[_0x5a5291(0x106)]()), app['use'](express[_0x5a5291(0xf8)]()), app[_0x5a5291(0x108)](app[_0x5a5291(0x10c)]), app['use'](express[_0x5a5291(0xf7)](__dirname + _0x5a5291(0x115)));
}), app[_0x3dcd55(0x105)](_0x3dcd55(0xf9), function () {
    var _0x14d030 = _0x3dcd55;
    app[_0x14d030(0x108)](express[_0x14d030(0xfa)]({'dumpExceptions': !![], 'showStack': !![]}));
}), app['configure'](_0x3dcd55(0x104), function () {
    var _0x63b036 = _0x3dcd55;
    app[_0x63b036(0x108)](express[_0x63b036(0xfa)]());
});
var port = process[_0x3dcd55(0x11c)][_0x3dcd55(0x10e)] || 0x1f40;
app[_0x3dcd55(0x118)](port, function () {
    var _0x45a7d2 = _0x3dcd55;
    console[_0x45a7d2(0x112)](_0x45a7d2(0x121), app[_0x45a7d2(0x11d)]()['port'], app[_0x45a7d2(0xfb)][_0x45a7d2(0x11c)]);
}), app['get']('/', routes['index']);
var stopwatch = new Stopwatch();
stopwatch['on'](_0x3dcd55(0x114), function (_0x17307f) {
    var _0x3f7c37 = _0x3dcd55;
    io[_0x3f7c37(0x116)][_0x3f7c37(0x119)]('time', {'time': _0x17307f});
}), stopwatch['on'](_0x3dcd55(0x100), function (_0x1aa70b) {
    var _0x36b075 = _0x3dcd55;
    io['sockets'][_0x36b075(0x119)](_0x36b075(0x109), {'time': _0x1aa70b});
}), stopwatch['start'](), io['sockets']['on']('connection', function (_0x22ee3d) {
    var _0x4f8cb6 = _0x3dcd55;
    io[_0x4f8cb6(0x116)][_0x4f8cb6(0x119)](_0x4f8cb6(0x109), {'time': stopwatch['getTime']()}), _0x22ee3d['on'](_0x4f8cb6(0x113), function () {
        stopwatch['start']();
    }), _0x22ee3d['on'](_0x4f8cb6(0x101), function () {
        var _0x427e7a = _0x4f8cb6;
        stopwatch[_0x427e7a(0x11f)]();
    }), _0x22ee3d['on'](_0x4f8cb6(0x103), function () {
        stopwatch['reset']();
    });
});

function _0x2c2f() {
    var _0x25bd6a = ['methodOverride', 'development', 'errorHandler', 'settings', '1459446EdFPcf', '6FSKKWu', 'socket.io', '5CnfFNo', 'reset:stopwatch', 'click:stop', 'exports', 'click:reset', 'production', 'configure', 'bodyParser', 'express', 'use', 'time', '3475090xDYtkF', './models/stopwatch', 'router', '2063105nodqpF', 'PORT', 'view\x20engine', '88903kjeXAc', '338037UWINBj', 'log', 'click:start', 'tick:stopwatch', '/public', 'sockets', 'ejs', 'listen', 'emit', './routes', '21mwFBna', 'env', 'address', '1161704TErURm', 'stop', '110104DCvUxb', 'Express\x20server\x20listening\x20on\x20port\x20%d\x20in\x20%s\x20mode', '333lQzTcb', 'logger', 'static'];
    _0x2c2f = function () {
        return _0x25bd6a;
    };
    return _0x2c2f();
}